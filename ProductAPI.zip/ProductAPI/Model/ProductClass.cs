﻿namespace ProductAPI.Model
{
    public class ProductClass
    {
        public int ProdId { get; set; }
        public string ProdName { get; set; }
        public string Price { get; set; }
    }
}
