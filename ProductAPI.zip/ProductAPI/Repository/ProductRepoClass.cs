﻿using Microsoft.AspNetCore.Mvc;
using ProductAPI.Model;

namespace ProductAPI.Repository
{
    public class ProductRepoClass : IProductInterface
    {
        public Task<List<ProductClass>> AddProduct(ProductClass Prod)
        {
            List<ProductClass> ProdList = new List<ProductClass>();
            ProdList = GetAllProducts().Result;
            ProdList.Add(Prod);
            return Task.FromResult(ProdList);
        }

        public Task<List<ProductClass>> GetAllProducts()
        {
           List<ProductClass> _ProdList= new List<ProductClass>()
           { new ProductClass{ProdId=101,ProdName="TV",Price="10000" },
           new ProductClass{ProdId=102,ProdName="AC",Price="15000" },
           new ProductClass{ProdId=103,ProdName="Laptop",Price="40000" },
          
           };

            return Task.FromResult(_ProdList);
        }

        public ProductClass GetProductById(int Id)
        {
            List<ProductClass> ProdList = new List<ProductClass>();
            ProdList= GetAllProducts().Result;
            if (ProdList.Count > 0) {

                var data = ProdList.FirstOrDefault(x => x.ProdId == Id);
                if (data != null) { return (ProductClass)data; }
                else { return null; }
            }
            else
            {
                return null;
            }
        }
    }
}
