﻿using ProductAPI.Model;

namespace ProductAPI.Repository
{
    public interface IProductInterface
    {
        Task<List<ProductClass>> GetAllProducts();
        Task<List<ProductClass>> AddProduct(ProductClass Prod);
        ProductClass GetProductById(int Id);
    }
}
