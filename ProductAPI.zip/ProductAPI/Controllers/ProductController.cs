﻿using Microsoft.AspNetCore.Mvc;
using ProductAPI.Model;
using ProductAPI.Repository;

namespace ProductAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
   
    public class ProductController : ControllerBase
    {
        private readonly IProductInterface _productRepo;

        
        public ProductController(IProductInterface productInterface)
        {
            _productRepo = productInterface;
        }

        [HttpGet]
       // [Route("AllProduct")]
        public async Task<List<ProductClass>> GetProducts() { 

            return await _productRepo.GetAllProducts();
        }

        [HttpPost]
       // [Route("AddProduct")]
        public async Task<List<ProductClass>> AddProduct([FromBody]ProductClass ProdData)
        {

            return await _productRepo.AddProduct(ProdData);
        }

        [HttpGet]
        [Route("ProductId/{Id}")]
        public IActionResult FetchProduct(int Id)
        {
            return Ok(_productRepo.GetProductById(Id));
        }


    }
}
